﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeManagementSystem.BL;
namespace EmployeeManagementSystem
{
    public partial class frmDepartment : Form
    {
        public frmDepartment()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtDepartmentName.Text=="")
            {
                lblrqDp.Text = "Please Enter Department Name ";
                txtDepartmentName.Focus();
            }
            else if (ddlDepartmentStatus.Text=="")
            {
                lblrqDS.Text = "Please Select Status";
                ddlDepartmentStatus.Focus();
            }
            else
            {
                Department obj = new Department();
                obj.IsNew = true;
                obj.DepartmentName = txtDepartmentName.Text;
                obj.Status = ddlDepartmentStatus.Text == "Active" ? true : false;
                BL_Department.Save(obj);
            }
           
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {

        }

        private void txtDepartmentName_TextChanged(object sender, EventArgs e)
        {
            if (txtDepartmentName.Text!="")
            {
                lblrqDp.Text = "";

            }
            else
            {
                lblrqDp.Text = "Please Enter Department Name ";

            }
        }

        private void ddlDepartmentStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblrqDS.Text = "";
        }
    }
}
