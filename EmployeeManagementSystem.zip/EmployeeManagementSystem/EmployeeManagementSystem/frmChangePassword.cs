﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeManagementSystem.BL;
namespace EmployeeManagementSystem
{
    public partial class frmChangePassword : Form
    {
        public frmChangePassword()
        {
            InitializeComponent();
        }

        private void btnSavePassword_Click(object sender, EventArgs e)
        {
            if (txtNewPassword.Text==txtRetypePassword.Text)
            {
                SystemUser obj = BL_SystemUser.Login(txtUserName.Text,txtCurrentPassword.Text);
                if (obj.UserID==0)
                {
                    MessageBox.Show("Invalid User Name or Password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    if (obj.Status==true)
                    {
                        obj.Password = txtNewPassword.Text;

                        BL_SystemUser.ChangePassword(obj);
                        MessageBox.Show("Information has been saved");

                    }
                    else
                    {
                        MessageBox.Show("Your account is disabled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }



                }
            }
            else
            {
                MessageBox.Show("Password not matched.","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
    }
}
