﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace EmployeeManagementSystem.DL
{
    class DataAccess
    {

        static SqlConnection con = new SqlConnection("data source=IRFANKHAN\\MSSQLSERVER_SQL1;initial catalog=EmployeeDB;integrated security=true");

        public static void ExecuteQuery(string query)
        {
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public static void ExecuteQuery(string query, SqlParameter[] prm)
        {
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddRange(prm);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public static DataTable GetDataTable(string query)
        {
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public static DataTable GetDataTable(string query, SqlParameter[] prm)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = query;
            cmd.Parameters.AddRange(prm);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);
            return dt;
        }

    }
}
