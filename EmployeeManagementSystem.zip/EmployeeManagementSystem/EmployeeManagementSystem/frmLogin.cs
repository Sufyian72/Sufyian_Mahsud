﻿using EmployeeManagementSystem.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeManagementSystem
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUserName.Text == "")
            {
                lblrqDp.Text = "Please Enter User Name";
                txtUserName.Focus();
            }
            else if (txtPassword.Text == "")
            {
                label4.Text = "Please Enter Password";
                txtPassword.Focus();
            }
            else
            {
                SystemUser obj = BL_SystemUser.Login(txtUserName.Text, txtPassword.Text);
                if (obj.UserID == 0)
                {
                    MessageBox.Show("Invalid username or password");
                }
                else
                {
                    if (obj.Status == true)
                    {
                        frmMainForm x = new frmMainForm();
                        x.ShowDialog();
                        this.Hide();

                    }
                    else
                    {
                        MessageBox.Show("Your account is inactive");
                    }
                }
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmChangePassword obj = new frmChangePassword();
            obj.ShowDialog();
            this.Hide();
        }
    }
}
