﻿using EmployeeManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem.BL
{
    class BL_SystemUser
    {



        public static void ChangePassword(int UserId,string password)
        {
            string query = "update tbl_systemuser set password=@password where userid="+UserId;
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@password",password);
            DataAccess.ExecuteQuery(query,prm);
        }
        public static void ChangePassword(SystemUser obj)
        {
            string query = "update tbl_systemuser set password=@password where userid=" + obj.UserID;
            SqlParameter[] prm = new SqlParameter[1];
            prm[0] = new SqlParameter("@password", obj.Password);
            DataAccess.ExecuteQuery(query, prm);
        }


        public static SystemUser Login(string UserName, string Password)
        {
            SystemUser user = new SystemUser();
            string query = "select * from tbl_SystemUser where UserName=@UserName and Password=@Password";
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@UserName", UserName);
            prm[1] = new SqlParameter("@Password", Password);
            DataTable dt = DataAccess.GetDataTable(query, prm);

            if (dt.Rows.Count>0)
            {
                user.Email = Convert.ToString(dt.Rows[0]["Email"]);
                user.UserID = Convert.ToInt32(dt.Rows[0]["UserID"]);
                user.UserName = Convert.ToString(dt.Rows[0]["UserName"]);
                user.IsAdmin = Convert.ToBoolean(dt.Rows[0]["IsAdmin"]);
                user.Status = Convert.ToBoolean(dt.Rows[0]["Status"]);

            }


            return user;
        }


    }
    public class SystemUser
    {
        public bool IsNew { get; set; }
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public bool Status { get; set; }
        public bool IsAdmin { get; set; }


    }
}
