﻿using EmployeeManagementSystem.DL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem.BL
{
    class BL_Department
    {
        public static void Save(Department x)
        {
            string query = "";
            if (x.IsNew == true)
            {
                query = "Insert into tbl_Department values(@DepartmentName,@Status)";
            }
            else
            {

                query = "update  tbl_Department set DepartmentName=@DepartmentName,Status=@Status where DepartmentID=" + x.DepartmentID;
            }
            SqlParameter[] prm = new SqlParameter[2];
            prm[0] = new SqlParameter("@DepartmentName", x.DepartmentName);
            prm[1] = new SqlParameter("@Status", x.Status);
            DataAccess.ExecuteQuery(query, prm);
        }
        public static void Get()
        {

        }
        public static void Get(int DepartmentID)
        {

        }
        public static void Delete()
        {

        }
    }
    class Department
    {

        public bool IsNew { get; set; }
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; }
        public bool Status { get; set; }


    }

}
