﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HBL12.Employee
{
    public partial class AccountLedger : System.Web.UI.Page
    {
        string constr = Convert.ToString(ConfigurationManager.ConnectionStrings["connectionstr"]);
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                loaddata();
            }

        }
        
        private void loaddata()
        {
            SqlConnection con = new SqlConnection(constr);
            string TransactionType = "select TransactionTypeId,TransactionType from tbl_TransactionType";

            SqlCommand cmd = new SqlCommand(TransactionType, con);
            con.Open();
            drptra.DataSource = cmd.ExecuteReader();
            drptra.DataBind();
            drptra.Items.Insert(0, "Select TransactionType");
        }
        
        protected void btnsearch_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(constr);
            string tra = "select AccountTitle,AccountName,Balance from tbl_AddNewAccount where AddNewAccountId ='" + txtaid.Text + "'";
            con.Open();
            SqlCommand cmd = new SqlCommand(tra, con);
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                txtat.Text = rd["AccountTitle"].ToString();
                txtcb.Text = rd["Balance"].ToString();
                this.txtat.ReadOnly = true;
                this.txtaid.ReadOnly = true;
                this.txtcb.ReadOnly = true;
                rd.Close();
                con.Close();
            }
            else { 
            
            }
            
        }
        protected void btnsub_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(constr);
                string qry = "";
                if (cbselect.SelectedIndex == 0)
                {
                    qry = "insert into Tbl_Transactions values('" + txtaid.Text + "','"+ txtta.Text.Trim() +"',0,'"+ this.drptra.SelectedValue +"',Getdate(),'Account Debited')";
                }
                else
                {
                    qry = "insert into Tbl_Transactions values('" + txtaid.Text + "',0,'" + txtta.Text.Trim() + "','" + this.drptra.SelectedValue + "',Getdate(),'Account Credited')";
                }
                SqlCommand cmd = new SqlCommand(qry, con);
                con.Open();
                cmd.ExecuteNonQuery();
                qry = "update Tbl_AddnewAccount set Balance ='" + txtrb.Text.Trim() + "' where AddNewAccountId= '" + txtaid.Text.Trim() + "' ";
                SqlCommand cmd1 = new SqlCommand(qry, con);
                cmd1.ExecuteNonQuery();
                con.Close();
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void grdtra_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdtra.PageIndex = e.NewPageIndex;
            loaddata();
        }
    }
}