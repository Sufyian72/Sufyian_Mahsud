﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HBL12.Employee
{
    public partial class Create_New_Account : System.Web.UI.Page
    {
        string constr = Convert.ToString(ConfigurationManager.ConnectionStrings["connectionstr"]);
        private int anaid = 0;
        public int AddNewAccountId
        {
            get
            {
                if (Request["anaid"] != "" && Request["anaid"] != null)
                {
                    return this.anaid = Convert.ToInt32(Request["anaid"]);
                }
                return this.anaid;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
               if (!IsPostBack)
            {
                loaddata();

                if (AddNewAccountId > 0)
                {
                    loadAddNewAccount();
                }
                
            }
         
        }
        private void loadAddNewAccount()
         {
             try {
                 SqlConnection con = new SqlConnection(constr);
                 string qry = "select * from Tbl_AddNewAccount where AddNewAccountId=" + this.AddNewAccountId;
                 SqlCommand cmd = new SqlCommand(qry, con);
                 SqlDataAdapter adp = new SqlDataAdapter(cmd);
                 DataTable dt = new DataTable();
                 DataSet ds = new DataSet();
                 adp.Fill(ds);
                 dt = ds.Tables[0];
                 if (dt.Rows.Count > 0)
                 {
                     this.txtAtitle.Text = Convert.ToString(dt.Rows[0]["AccountTitle"]);
                     this.txtahn.Text = Convert.ToString(dt.Rows[0]["AccountName"]);
                     this.txtFname.Text = Convert.ToString(dt.Rows[0]["FatherName"]);
                     this.txtadd.Text = Convert.ToString(dt.Rows[0]["Address"]);
                     this.txtpn.Text = Convert.ToString(dt.Rows[0]["PhoneNumber"]);
                     this.txtemail.Text = Convert.ToString(dt.Rows[0]["Email"]);
                     if (Convert.ToBoolean(dt.Rows[0]["Gender"]) == true && dt.Rows[0]["Gender"] != null)
                     {
                         this.rbGender.Items[0].Selected = true;

                     }
                     else if (Convert.ToBoolean(dt.Rows[0]["Gender"]) == false && dt.Rows[0]["Gender"] != null)
                     {
                         this.rbGender.Items[1].Selected = true;
                     }
                     this.txtbal.Text = Convert.ToString(dt.Rows[0]["Balance"]);
                     this.DrpAccountType.SelectedValue = Convert.ToString(dt.Rows[0]["AccountType"]);
                     this.drpstatus.SelectedValue = Convert.ToString(dt.Rows[0]["Status"]);
                     
                 }
                 
             }
             catch (Exception ex)
             {
                 Response.Write("Error Occured while Loading....... !");
             }
        }
        private void loaddata()
        {
            SqlConnection con = new SqlConnection(constr);
            string AccountType = "select AccountTypeId,AccountType from Tbl_AccountType";
            SqlCommand cmd = new SqlCommand(AccountType, con);
            con.Open();
            DrpAccountType.DataSource = cmd.ExecuteReader();
            DrpAccountType.DataBind();
            DrpAccountType.Items.Insert(0, "Select Account Type");
        }

        protected void btncna_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (Page.IsValid)
                {
                    string qry = "";
                    Guid g;
                    g = Guid.NewGuid();
                    string AccUser = Convert.ToString(g).Replace('-', ' ').Substring(0, 4).ToString();
                    string UserName = this.txtAtitle.Text.Substring(0, 5) + AccUser;
                    string Password = this.txtahn.Text.Substring(0, 4) + AccUser;
                    SqlConnection con = new SqlConnection(constr);
                    if (AddNewAccountId > 0)
                    {
                        qry = "update Tbl_AddNewAccount set AccountTitle='" + txtAtitle.Text + "',AccountName='" + txtahn.Text + "',FatherName='" + txtFname.Text + "',Address='" + txtadd.Text + "',PhoneNumber='" + txtpn.Text + "',Email='" + txtemail.Text + "',Balance='" + txtbal.Text + "',AccountType=" + DrpAccountType.SelectedValue + ",Status=" + drpstatus.SelectedValue + ",Gender='" + rbGender.SelectedValue + "' Where AddNewAccountId='" + AddNewAccountId + "'"; 
                    }
                    else
                    {
                        qry = "insert into tbl_AddNewAccount (AccountTitle,AccountName,FatherName,Address,PhoneNumber,Email,Balance,AccountType,Status,Gender,UserName,Password,CreatedDateTime) values('" + txtAtitle.Text + "','" + txtahn.Text + "','" + txtFname.Text + "','" + txtadd.Text + "','" + txtpn.Text + "','" + txtemail.Text + "','" + txtbal.Text + "'," + DrpAccountType.SelectedValue + ",'" + drpstatus.SelectedValue + "','" + rbGender.SelectedValue + "','" + UserName + "','" + Password + "',Getdate()) select @@Identity;"; 
                    }
                    SqlCommand cmd = new SqlCommand(qry, con);
                    con.Open();
                    int id= cmd.ExecuteNonQuery();
                    qry = "insert into tbl_Transactions values('" + id + "','"+ txtbal.Text + "',0,4,Getdate(),'"+ " Opening Account" + "')";
                    
                    SqlCommand cmd1 = new SqlCommand(qry, con);
                    //int k = cmd1.ExecuteNonQuery();
                    //cmd1.ExecuteNonQuery();
                    //if (k > 0)
                        if (AddNewAccountId > 0)
                        {
                            Response.Write("Updated Successfully");
                        }
                        else
                        {
                            Response.Write("Registration Successfully...");
                        }

                    
                    con.Close();

                    Response.Redirect("AddNewAccountDetails.aspx");
                    
                    clearAll();

                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
        private void clearAll()
        {
            txtAtitle.Text = "";
            txtahn.Text = "";
            txtFname.Text = "";
            txtadd.Text = "";
            txtpn.Text = "";
            txtemail.Text = "";
            rbGender.SelectedValue = "";
            txtbal.Text = "";
            DrpAccountType.SelectedIndex = -1;

        }

       
    }
}