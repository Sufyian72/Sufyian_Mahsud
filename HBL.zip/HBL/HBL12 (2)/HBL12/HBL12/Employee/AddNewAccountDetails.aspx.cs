﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HBL12.Employee
{
    public partial class AddNewAccountDetails : System.Web.UI.Page
    {
        string constr = Convert.ToString(ConfigurationManager.ConnectionStrings["connectionstr"]);

        protected void Page_Load(object sender, EventArgs e)
        {
            loaddata();
        }
        private void loaddata()
        {
            SqlConnection con = new SqlConnection(constr);
            String select = @"select ANA.AddNewAccountId,ANA.AccountTitle,ANA.AccountName,ANA.FatherName,ANA.Address,ANA.PhoneNumber,ANA.Email,ANA.Balance,AT.AccountType,
(Case When ANA.Status=1 Then 'Active'
 When ANA.Status = 0 Then 'InActive' End) [Status],
(Case When ANA.Gender = 1 Then 'Male'
 When ANA.Gender = 0 Then 'Femail' End) [Gender] from Tbl_AddNewAccount ANA
Inner Join Tbl_AccountType AT on ANA.AccountType = AT.AccountTypeId";
            SqlCommand cmd = new SqlCommand(select, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(ds);
            dt = ds.Tables[0];
            grdacc.DataSource = dt;
            grdacc.DataBind();
        }

        //protected void lnkEdit_Click(object sender, EventArgs e)
        //{
        //    LinkButton btn = (LinkButton)sender;
        //    string AddNewAccountId = btn.CommandArgument;
        //    Response.Redirect("CreateNewAccount.aspx?anaid=" + AddNewAccountId);
        //}

        //protected void lnkDelete_Click(object sender, EventArgs e)
        //{
        //    LinkButton btn = (LinkButton)sender;
        //    string AddNewAccountId = btn.CommandArgument;
        //    string qry = "Delete from Tbl_AddNewAccount where AddNewAccountId=" + AddNewAccountId;
        //    SqlConnection con = new SqlConnection(constr);
        //    SqlCommand cmd = new SqlCommand(qry, con);
        //    con.Open();
        //    int i = cmd.ExecuteNonQuery();
        //    con.Close();
        //    if (i > 0)
        //    {
        //        Response.Write("Deleted Successfully");
        //    }
        //    else
        //    {
        //        Response.Write("Failed to Delete Account");
        //    }
        //    loaddata();  
        //}
         
        protected void grdacc_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdacc.PageIndex = e.NewPageIndex;
            loaddata();
        }
    }
}