﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HBL12.Employee
{
    public partial class Login : System.Web.UI.Page
    {
        string constr = Convert.ToString(ConfigurationManager.ConnectionStrings["connectionstr"]);

        protected void Page_Load(object sender, EventArgs e)
        {
            this.lblmsg.Text = "";
        }

        protected void btnELogin_Click(object sender, EventArgs e)
        {
            
            
            if (!(txtuser.Text == "" || txtPass.Text == ""))
            {

                SqlConnection con = new SqlConnection(constr);
                string select = "select * from tbl_Employee where Username='" + txtuser.Text.Trim() + "' and password='" + txtPass.Text.Trim() + "'";
                SqlCommand cmd = new SqlCommand(select, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();
                da.Fill(ds);
                dt = ds.Tables[0];
                if (dt.Rows.Count > 0)
                {
                    Session["EmployeeId"] = Convert.ToString(dt.Rows[0]["EmployeeId"]);
                    Response.Redirect("Default.aspx");
                }
                else
                {
                    this.lblmsg.ForeColor = System.Drawing.Color.Red;
                    this.lblmsg.Text = "Invalid Username or Password";
                }
            }
            else
            {
                this.lblmsg.Text = "Please Enter Username or Password";
            }
             
        }
    }
}