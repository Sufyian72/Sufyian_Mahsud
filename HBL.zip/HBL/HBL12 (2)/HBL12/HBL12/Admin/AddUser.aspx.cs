﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HBL12.Admin
{
    public partial class AddUser : System.Web.UI.Page
    {
        string con = Convert.ToString(ConfigurationManager.ConnectionStrings["connectionstr"]);
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}