﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HBL12.Admin
{
    public partial class City : System.Web.UI.Page
    {
        string constr = Convert.ToString(ConfigurationManager.ConnectionStrings["connectionstr"]);

        private int Cid = 0;
        public int CityId
        {
            get
            {
                if (Request["CityId"] != "" && Request["CityId"] != null)
                {
                    return this.Cid = Convert.ToInt32(Request["CityId"]);
                }
                return this.Cid;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (CityId > 0)
                {
                    loadCity();
                }
                load();
            }
            
            
            
        }
        private void loadCity()
        {
            try
            {
                SqlConnection con = new SqlConnection(constr);
                string qry = "select * from Tbl_City where CityId=" + this.CityId;
                SqlCommand cmd = new SqlCommand(qry, con);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                DataSet ds = new DataSet();
                adp.Fill(ds);
                dt = ds.Tables[0];
                if (dt.Rows.Count > 0)
                {
                    this.txtCity.Text = Convert.ToString(dt.Rows[0]["City"]);
                    this.txtZcode.Text = Convert.ToString(dt.Rows[0]["ZipCode"]);
                    this.txtZone.Text = Convert.ToString(dt.Rows[0]["Zone"]);
                }
            }
            catch (Exception ex)
            {
                Response.Write("Error Occured while Loading....... !");
            }
        }
        private void load()
        {
            SqlConnection con = new SqlConnection(constr);
            String select = "select * from tbl_city";
            SqlCommand cmd = new SqlCommand(select, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(ds);
            dt = ds.Tables[0];
            grdcity.DataSource = dt;
            grdcity.DataBind();
        }

        protected void btnCity_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    string qry = "";
                    SqlConnection con = new SqlConnection(constr);
                    if (CityId > 0)
                    {
                        qry = "update tbl_City set City='" + txtCity.Text + "',ZipCode='" + txtZcode.Text + "',Zone='" + txtZone.Text + "' where CityId=" + CityId;
                    }
                    else
                    {
                      qry = "insert into tbl_City values('" + txtCity.Text + "','" + txtZcode.Text + "','" + txtZone.Text + "')";
                    }
                    SqlCommand cmd = new SqlCommand(qry, con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    if (CityId > 0)
                    {
                        Response.Write("Updated Successfully");
                    }
                    else
                    {
                        Response.Write("Registration Successfully...");
                    }
                    con.Close();
                    Response.Write("City Successfully Entered...");
                    load();

                    ClearAll();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        private void ClearAll()
        {
            txtCity.Text = "";
            txtZcode.Text = "";
            txtZone.Text = "";

        }
        protected void lnkEdit_Click(object sender, EventArgs e)
        {
            LinkButton btn = (LinkButton)sender;
            string CityId = btn.CommandArgument;
            Response.Redirect("City.aspx?CityId=" + CityId);
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            LinkButton btn = (LinkButton)sender;
            string Cityid = btn.CommandArgument;
            string qry = "Delete from Tbl_City where CityId=" + CityId;
            SqlConnection con = new SqlConnection(constr);
            SqlCommand cmd = new SqlCommand(qry, con);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            if (i > 0)
            {
                Response.Write("Deleted Successfully");
            }
            else
            {
                Response.Write("Failed to Delete Branch");
            }
            load();  
        }

        protected void grdcity_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdcity.PageIndex = e.NewPageIndex;
            load();
        }
        }
    }
