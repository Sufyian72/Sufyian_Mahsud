﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HBL12.Admin
{
    public partial class Branch : System.Web.UI.Page
    {
        string constr = Convert.ToString(ConfigurationManager.ConnectionStrings["connectionstr"]);

        private int Braid = 0;
        public int Branchid
        {
            get {
                if (Request["Braid"] != "" && Request["Braid"] != null)
                {
                    return this.Braid = Convert.ToInt32(Request["Braid"]);
                }
                return this.Braid;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Branchid > 0)
                {
                    loadBranch();
                }
                load();
            }
           
            
        }
        private void loadBranch()
        {
            try
            {
                SqlConnection con = new SqlConnection(constr);
                string qry = "select * from Tbl_Branch where Branchid=" + this.Branchid;
                SqlCommand cmd = new SqlCommand(qry, con);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                DataSet ds = new DataSet();
                adp.Fill(ds);
                dt = ds.Tables[0];
                if (dt.Rows.Count > 0)
                {
                    this.txtBname.Text = Convert.ToString(dt.Rows[0]["BranchName"]);
                    this.txtAdd.Text = Convert.ToString(dt.Rows[0]["Address"]);
                    this.txtCity.Text = Convert.ToString(dt.Rows[0]["City"]);
                }
            }
            catch (Exception ex)
            {
                Response.Write("Error Occured while Loading....... !");
            }
        }

        private void load()
        {
            SqlConnection con = new SqlConnection(constr);
            String select = "select * from tbl_branch";
            SqlCommand cmd = new SqlCommand(select, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(ds);
            dt = ds.Tables[0];
            grdbranch.DataSource = dt;
            grdbranch.DataBind();
        }

        protected void btnBranch_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    string qry = "";
                    SqlConnection con = new SqlConnection(constr);
                    if (Branchid > 0)
                    {
                        qry = "update tbl_Branch set BranchName='" + txtBname.Text + "',Address='" + txtAdd.Text + "',City='" + txtCity.Text + "' where BranchId="+Branchid;
                    }
                    else
                    {
                      qry = "insert into tbl_Branch values('" + txtBname.Text + "','" + txtAdd.Text + "','" + txtCity.Text + "')";
                    }
                    SqlCommand cmd = new SqlCommand(qry, con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    if (Branchid > 0)
                    {
                        Response.Write("Updated Successfully");
                    }
                    else
                    {
                        Response.Write("Registration Successfully...");
                    }
                    con.Close();
                    Response.Write("Branch Successfully Entered...");
                    load();

                    ClearAll();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
        private void ClearAll()
        {

            txtAdd.Text = "";
            txtBname.Text = "";
            txtCity.Text = "";

        }

        protected void lnkEdit_Click(object sender, EventArgs e)
        {
            LinkButton btn = (LinkButton)sender;
            string BranchId = btn.CommandArgument;
            Response.Redirect("Branch.aspx?Braid=" + BranchId);
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            LinkButton btn = (LinkButton)sender;
            string Branchid = btn.CommandArgument;
            string qry = "Delete from Tbl_Branch where Branchid=" + Branchid;
            SqlConnection con = new SqlConnection(constr);
            SqlCommand cmd = new SqlCommand(qry, con);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            if (i > 0)
            {
                Response.Write("Deleted Successfully");
            }
            else
            {
                Response.Write("Failed to Delete Branch");
            }
            load();  
        }

        protected void grdbranch_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdbranch.PageIndex = e.NewPageIndex;
            load();
        }
    }
}
