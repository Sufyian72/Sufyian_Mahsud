﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HBL12.Admin
{
    public partial class Designation : System.Web.UI.Page
    {
        string constr = Convert.ToString(ConfigurationManager.ConnectionStrings["connectionstr"]);
        private int Desid = 0;
        public int DesignationId
        {
            get
            {
                if (Request["Desid"] != "" && Request["Desid"] != null)
                {
                    return this.Desid = Convert.ToInt32(Request["Desid"]);
                }
                return this.Desid;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (!IsPostBack)
            {
                if (DesignationId > 0)
                {
                    loadDesignation();
                }
                load();
            }
        }

            private void loadDesignation()
            {
                try
                {
                    SqlConnection con = new SqlConnection(constr);
                    string qry = "select * from Tbl_Designation where DesignationId=" + this.DesignationId;
                    SqlCommand cmd = new SqlCommand(qry, con);
                    SqlDataAdapter adp = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    DataSet ds = new DataSet();
                    adp.Fill(ds);
                    dt = ds.Tables[0];
                    if (dt.Rows.Count > 0)
                    {
                        this.txtDes.Text = Convert.ToString(dt.Rows[0]["Designation"]);
                    }
                }
                catch (Exception ex)
                {
                    Response.Write("Error Occured while Loading....... !");
                }
            }
        private void load()
        {
            SqlConnection con = new SqlConnection(constr);
            String select = "select * from tbl_designation";
            SqlCommand cmd = new SqlCommand(select, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(ds);
            dt = ds.Tables[0];
            grddesignation.DataSource = dt;
            grddesignation.DataBind();
        }

        protected void btnDesignation_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    string qry = "";
                    SqlConnection con = new SqlConnection(constr);
                    if (DesignationId > 0)
                    {
                        qry = "update tbl_Designation set Designation='" + txtDes.Text + "' where DesignationId=" + DesignationId;
                    }
                    else
                    {
                        qry = "insert into tbl_Designation values('" + txtDes.Text + "')";
                    }
                    SqlCommand cmd = new SqlCommand(qry, con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    if (DesignationId > 0)
                    {
                        Response.Write("Updated Successfully");
                    }
                    else
                    {
                        Response.Write("Registration Successfully...");
                    }
                    con.Close();
                    Response.Write("Designation Successfully Entered...");
                    load();

                    txtDes.Text = "";

                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void lnkEdit_Click(object sender, EventArgs e)
        {
            LinkButton btn = (LinkButton)sender;
            string DesignationId = btn.CommandArgument;
            Response.Redirect("Designation.aspx?Desid=" + DesignationId);
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            LinkButton btn = (LinkButton)sender;
            string DesignationId = btn.CommandArgument;
            string qry = "Delete from Tbl_Designation where DesignationId=" + DesignationId;
            SqlConnection con = new SqlConnection(constr);
            SqlCommand cmd = new SqlCommand(qry, con);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            if (i > 0)
            {
                Response.Write("Deleted Successfully");
            }
            else
            {
                Response.Write("Failed to Delete Designation");
            }
            load();    
        }

        protected void grddesignation_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grddesignation.PageIndex = e.NewPageIndex;
            load();
        }
    }
}