﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HBL12.Admin
{
    public partial class Zone : System.Web.UI.Page
    {
        string constr = Convert.ToString(ConfigurationManager.ConnectionStrings["connectionstr"]);

        private int Zid = 0;
        public int ZoneId
        {
            get
            {
                if (Request["ZoneId"] != "" && Request["ZoneId"] != null)
                {
                    return this.Zid = Convert.ToInt32(Request["ZoneId"]);
                }
                return this.Zid;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (ZoneId > 0)
                {
                    loadZone();
                }
                load();
            }
            
            

        }
        private void loadZone()
        {
            try
            {
                SqlConnection con = new SqlConnection(constr);
                string qry = "select * from Tbl_Zone where ZoneId=" + this.ZoneId;
                SqlCommand cmd = new SqlCommand(qry, con);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                DataSet ds = new DataSet();
                adp.Fill(ds);
                dt = ds.Tables[0];
                if (dt.Rows.Count > 0)
                {
                    this.txtZone.Text = Convert.ToString(dt.Rows[0]["Zone"]);
                    
                }
            }
            catch (Exception ex)
            {
                Response.Write("Error Occured while Loading....... !");
            }
        }
        private void load()
        {
            SqlConnection con = new SqlConnection(constr);
            String select = "select * from tbl_zone";
            SqlCommand cmd = new SqlCommand(select, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(ds);
            dt = ds.Tables[0];
            grdzone.DataSource = dt;
            grdzone.DataBind();
        }

        protected void btnZone_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    string qry = "";
                    SqlConnection con = new SqlConnection(constr);
                    if (ZoneId > 0)
                    {
                        qry = "update tbl_Zone set Zone='" + txtZone.Text + "' where ZoneId=" + ZoneId;
                    }
                    else
                    {
                      qry = "insert into tbl_zone values('" + txtZone.Text + "')";
                    }
                    SqlCommand cmd = new SqlCommand(qry, con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    if (ZoneId > 0)
                    {
                        Response.Write("Updated Successfully");
                    }
                    else
                    {
                        Response.Write("Registration Successfully...");
                    }
                    con.Close();
                    Response.Write("Zone Successfully Entered...");
                    load();

                    txtZone.Text = "";

                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void lnkEdit_Click(object sender, EventArgs e)
        {
            LinkButton btn = (LinkButton)sender;
            string ZoneId = btn.CommandArgument;
            Response.Redirect("Zone.aspx?ZoneId=" + ZoneId);
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            LinkButton btn = (LinkButton)sender;
            string ZoneId = btn.CommandArgument;
            string qry = "Delete from Tbl_Zone where ZoneId=" + ZoneId;
            SqlConnection con = new SqlConnection(constr);
            SqlCommand cmd = new SqlCommand(qry, con);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            if (i > 0)
            {
                Response.Write("Deleted Successfully");
            }
            else
            {
                Response.Write("Failed to Delete Branch");
            }
            load();  
        }

        protected void grdzone_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdzone.PageIndex = e.NewPageIndex;
            load();
        }
        }
    }
