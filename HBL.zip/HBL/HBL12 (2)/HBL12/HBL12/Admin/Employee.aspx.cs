﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HBL12.Admin
{
    public partial class Employee : System.Web.UI.Page
    {
        string constr = Convert.ToString(ConfigurationManager.ConnectionStrings["connectionstr"]);
        private int Empid = 0;
        public int EmployeeId
        {
            get {
                if (Request["Empid"] != "" && Request["Empid"] != null)
                {
                    return this.Empid = Convert.ToInt32(Request["Empid"]);
                }
                return this.Empid;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {

            
            if (!IsPostBack)
            {
                loaddata();
                
                if (EmployeeId > 0)
                {
                    loadEmployee();
                }
                
            }
         
        }
        private void loadEmployee()
         {
             try {
                 SqlConnection con = new SqlConnection(constr);
                 string qry = "select * from Tbl_Employee where EmployeeId=" + this.EmployeeId;
                 SqlCommand cmd = new SqlCommand(qry, con);
                 SqlDataAdapter adp = new SqlDataAdapter(cmd);
                 DataTable dt = new DataTable();
                 DataSet ds = new DataSet();
                 adp.Fill(ds);
                 dt = ds.Tables[0];
                 if (dt.Rows.Count > 0)
                 {
                     this.txtEname.Text = Convert.ToString(dt.Rows[0]["EName"]);
                     this.txtFname.Text = Convert.ToString(dt.Rows[0]["Fname"]);
                     this.txtAddress.Text = Convert.ToString(dt.Rows[0]["Address"]);
                     this.DrpCity.SelectedValue = Convert.ToString(dt.Rows[0]["City"]);
                     this.txtPhone.Text = Convert.ToString(dt.Rows[0]["PhoneNumber"]);
                     this.txtMobile.Text = Convert.ToString(dt.Rows[0]["MobileNumber"]);
                     if (Convert.ToBoolean(dt.Rows[0]["Gender"]) == true && dt.Rows[0]["Gender"] != null)
                     {
                         this.rbGender.Items[0].Selected = true;

                     }
                     else if (Convert.ToBoolean(dt.Rows[0]["Gender"]) == false && dt.Rows[0]["Gender"] != null)
                     {
                         this.rbGender.Items[1].Selected = true;
                     }
                     this.txtAge.Text = Convert.ToString(dt.Rows[0]["Age"]);
                     this.DrpStatus.SelectedValue = Convert.ToString(dt.Rows[0]["IsActive"]);
                     this.txtNic.Text = Convert.ToString(dt.Rows[0]["Nic"]);
                     this.txtEmail.Text = Convert.ToString(dt.Rows[0]["Email"]);
                     this.DrpDesignation.SelectedValue = Convert.ToString(dt.Rows[0]["Desgination"]);
                     this.DrpBranch.SelectedValue = Convert.ToString(dt.Rows[0]["BranchName"]);
                 }
                 
             }
             catch (Exception ex)
             {
                 Response.Write("Error Occured while Loading....... !");
             }
        }
        private void loaddata()
        {
            SqlConnection con = new SqlConnection(constr);
            string city = "select CityId,City from tbl_city";
            string designation = "select DesignationId,Designation from tbl_designation";
            string branch = "select Branchid,BranchName from tbl_branch";
            
            SqlCommand cmd = new SqlCommand(city, con);
            SqlCommand cmd1 = new SqlCommand(designation, con);
            SqlCommand cmd2 = new SqlCommand(branch, con);
            
            con.Open();
            DrpCity.DataSource = cmd.ExecuteReader();
            DrpCity.DataBind();
            DrpCity.Items.Insert(0, "Select City");
            con.Close();
            con.Open();
            DrpDesignation.DataSource = cmd1.ExecuteReader();
            DrpDesignation.DataBind();
            DrpDesignation.Items.Insert(0, "Select Designation");
            con.Close();
            con.Open();
            DrpBranch.DataSource = cmd2.ExecuteReader();
            DrpBranch.DataBind();
            DrpBranch.Items.Insert(0, "Select Branch");
            
        }
        protected void btnEmployee_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (Page.IsValid)
                {
                    string qry = "";
                    Guid g;
                    g = Guid.NewGuid();
                    string EmpUser = Convert.ToString(g).Replace('-', ' ').Substring(0, 4).ToString();
                    string username = this.DrpBranch.SelectedItem.Text.Substring(0, 5).ToString() + EmpUser;
                    string password = this.txtEname.Text.Substring(0, 4) + EmpUser;
                    SqlConnection con = new SqlConnection(constr);
                    if (EmployeeId > 0)
                    {
                        qry = "update Tbl_Employee set EName='" + txtEname.Text + "',Fname='" + txtFname.Text + "',Address='" + txtAddress.Text + "',City=" + DrpCity.SelectedValue + ",PhoneNumber='" + txtPhone.Text + "',MobileNumber='" + txtMobile.Text + "',Gender='" + rbGender.SelectedValue + "',Age=" + txtAge.Text + ",IsActive=" + DrpStatus.SelectedValue + ",NIC='" + txtNic.Text + "',Email='" + txtEmail.Text + "',Desgination=" + DrpDesignation.SelectedValue + ",Branch=" + DrpBranch.SelectedValue + " Where EmployeeId='" + EmployeeId + "'"; 
                    }
                    else
                    {
                        qry = "insert into tbl_Employee (EName,Fname,Address,City,PhoneNumber,MobileNumber,Gender,Age,IsActive,NIC,Email,Desgination,Branch,username,password,CreatedDate) values('" + txtEname.Text + "','" + txtFname.Text + "','" + txtAddress.Text + "'," + DrpCity.SelectedValue + ",'" + txtPhone.Text + "','" + txtMobile.Text + "','" + rbGender.SelectedValue + "','" + txtAge.Text + "','" + DrpStatus.SelectedValue + "','" + txtNic.Text + "','" + txtEmail.Text + "'," + DrpDesignation.SelectedValue + "," + DrpBranch.SelectedValue + ",'" + username + "','" + password + "',Getdate())";
                    }
                    SqlCommand cmd = new SqlCommand(qry, con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    
                        if (EmployeeId > 0)
                        {
                            Response.Write("Updated Successfully");
                        }
                        else
                        {
                            Response.Write("Registration Successfully...");
                        }
                    
                    con.Close();
                    
                    Response.Redirect("EmployeeDetails.aspx");
                    clearAll();

                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
        private void clearAll()
        {
            txtAddress.Text = "";
            txtAge.Text = "";
            txtEmail.Text = "";
            txtEname.Text = "";
            txtFname.Text = "";
            txtMobile.Text = "";
            txtNic.Text = "";
            txtPhone.Text = "";
            rbGender.SelectedValue = "";
            DrpDesignation.SelectedIndex = -1;
            DrpCity.SelectedIndex = -1;
            DrpBranch.SelectedIndex = -1;
           
        }

        

    }
}