﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HBL12.Admin
{
    public partial class EmployeeDetails : System.Web.UI.Page
    {
        string constr = Convert.ToString(ConfigurationManager.ConnectionStrings["connectionstr"]);

        protected void Page_Load(object sender, EventArgs e)
        {

            loaddata();
        }
        private void loaddata()
        {
            SqlConnection con = new SqlConnection(constr);
            String select = @"select EE.Employeeid,EE.Ename,EE.Fname,EE.Address,EE.Email,EE.NIC,CT.City,EE.PhoneNumber,EE.MobileNumber,
(Case When EE.IsActive=1 Then 'Active' 
When EE.IsActive=0 Then 'InActive' End)[IsActive],
(Case When EE.Gender=1 Then 'Male' 
When EE.Gender=0 Then 'Female' End)[Gender],D.Designation,Br.BranchName from Tbl_Employee EE
Inner Join Tbl_Branch Br on EE.Branch=Br.Branchid
inner join Tbl_Designation D on EE.Desgination= D.DesignationId
inner join Tbl_City Ct on EE.City= Ct.Cityid";

            SqlCommand cmd = new SqlCommand(select, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(ds);
            dt = ds.Tables[0];
            grdemployee.DataSource = dt;
            grdemployee.DataBind();
        }
     
        protected void lnkEdit_Click(object sender, EventArgs e)
        {
            LinkButton btn = (LinkButton)sender;
            string EmployeeId = btn.CommandArgument;
            Response.Redirect("Employee.aspx?Empid=" + EmployeeId);
             
            
        
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            LinkButton btn = (LinkButton)sender;
            string EmployeeId = btn.CommandArgument;
            string qry = "Delete from Tbl_Employee where EmployeeId=" + EmployeeId;
            SqlConnection con = new SqlConnection(constr);
            SqlCommand cmd = new SqlCommand(qry, con);
            con.Open();
            int i= cmd.ExecuteNonQuery();
            con.Close();
            if (i > 0)
            {
                Response.Write("Deleted Successfully");
            }
            else
            {
                Response.Write("Failed to Delete Employee");
            }
            loaddata();
        }

        protected void grdemployee_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdemployee.PageIndex = e.NewPageIndex;
            loaddata();
        }

    }
}