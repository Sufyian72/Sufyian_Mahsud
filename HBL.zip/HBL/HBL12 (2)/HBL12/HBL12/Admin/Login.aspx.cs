﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HBL12
{
    public partial class Login : System.Web.UI.Page
    {
        string constr = Convert.ToString(ConfigurationManager.ConnectionStrings["connectionstr"]);

        protected void Page_Load(object sender, EventArgs e)
        {
            this.lblmsg.Text = "";
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            if (!(this.txtuser.Text=="" || this.txtPass.Text == ""))
            {
                SqlConnection con = new SqlConnection(constr);
                string select = "select * from tbl_Admin where username='" + this.txtuser.Text.Trim() + "' and password='" + this.txtPass.Text.Trim() + "'";
                SqlCommand cmd = new SqlCommand(select, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();
                da.Fill(ds);
                dt = ds.Tables[0];
                if (dt.Rows.Count > 0)
                {
                    Session["AdminId"] = Convert.ToString(dt.Rows[0]["AdminId"]);
                    Response.Redirect("Default.aspx");
                }
                else
                {
                    this.lblmsg.ForeColor = System.Drawing.Color.Red;
                    this.lblmsg.Text = "Invalid Username or Password";
                }
            }
            else
            {
                this.lblmsg.Text = "Please Enter Username or Password";
            }
            
        }
    }
}