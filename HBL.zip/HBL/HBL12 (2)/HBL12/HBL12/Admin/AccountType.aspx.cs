﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HBL12.Admin
{
    public partial class AccountType1 : System.Web.UI.Page
    {

        string constr = Convert.ToString(ConfigurationManager.ConnectionStrings["connectionstr"]);
        private int AccTpyid = 0;
        public int AccountTypeId
        {
            get
            {
                if (Request["AccTypid"] != "" && Request["AccTypid"] != null)
                {
                    return AccTpyid = Convert.ToInt32(Request["AccTypid"]);
                }
                return this.AccTpyid;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (!IsPostBack)
            {
                if (AccountTypeId > 0)
                {
                    loadAccountType();
                }
                load();
            }
        }

        private void loadAccountType()
        { 
            try
            {
                    SqlConnection con = new SqlConnection(constr);
                    string qry = "select * from Tbl_AccountType where AccountTypeId=" + this.AccountTypeId;
                    SqlCommand cmd = new SqlCommand(qry, con);
                    SqlDataAdapter adp = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    DataSet ds = new DataSet();
                    adp.Fill(ds);
                    dt = ds.Tables[0];
                    if (dt.Rows.Count > 0)
                    {
                        this.txtat.Text = Convert.ToString(dt.Rows[0]["AccountType"]);
                    }
                }
                catch (Exception ex)
                {
                    Response.Write("Error Occured while Loading....... !");
                }
            }

        private void load()
        { 
            SqlConnection con = new SqlConnection(constr);
            String select = "select * from tbl_AccountType";
            SqlCommand cmd = new SqlCommand(select, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(ds);
            dt = ds.Tables[0];
            grdacctyp.DataSource = dt;
            grdacctyp.DataBind();
        }
    

        protected void btnat_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    string qry = "";
                    SqlConnection con = new SqlConnection(constr);
                    if (AccountTypeId > 0)
                    {
                        qry = "update tbl_AccountType set AccountType='" + txtat.Text + "' where AccountTypeId=" + AccountTypeId;
                    }
                    else
                    {
                        qry = "insert into tbl_AccountType values('" + txtat.Text + "')";
                    }
                    SqlCommand cmd = new SqlCommand(qry, con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    if (AccountTypeId > 0)
                    {
                        Response.Write("updated successfully");
                    }
                    else
                    {
                        Response.Write("registration successfully...");
                    }
                    con.Close();
                    Response.Write("AccountType successfully entered...");
                    load();

                    txtat.Text = "";

                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void lnkEdit_Click(object sender, EventArgs e)
        {
            LinkButton btn = (LinkButton)sender;
            string AccountTypeId = btn.CommandArgument;
            Response.Redirect("AccountType.aspx?AccTypid=" + AccountTypeId);
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            LinkButton btn = (LinkButton)sender;
            string AccountTypeId = btn.CommandArgument;
            string qry = "Delete from Tbl_AccountType where AccountTypeId=" + AccountTypeId;
            SqlConnection con = new SqlConnection(constr);
            SqlCommand cmd = new SqlCommand(qry, con);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            if (i > 0)
            {
                Response.Write("Deleted Successfully");
            }
            else
            {
                Response.Write("Failed to Delete AccountType");
            }
            load();    
        }

        protected void grdacctyp_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdacctyp.PageIndex = e.NewPageIndex;
            load();
        }
    }
}