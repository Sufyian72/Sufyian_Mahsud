﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace HBL12.BL
{
    public class NewHelper
    {
        public static string GetEmployeeName(string EmployeeId)
        {

            string constr = Convert.ToString(ConfigurationManager.ConnectionStrings["connectionstr"]);
            string name = "";
            SqlConnection con = new SqlConnection(constr);
            String select = "select Username from tbl_Employee where EmployeeId=" + EmployeeId + "";
            SqlCommand cmd = new SqlCommand(select, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(ds);
            dt = ds.Tables[0];
            if (dt.Rows.Count > 0)
            {

                name = Convert.ToString(dt.Rows[0]["Username"]);
            }

            return name;
        }

    }
}